import { GoogleGenerativeAI } from '@google/generative-ai';
import { NextResponse } from 'next/server';
import { FALLBACK_EVENTS } from '@/lib/fallback-events';

const apiKey = process.env.GEMINI_API_KEY;
const genAI = apiKey ? new GoogleGenerativeAI(apiKey) : null;

// Helper to pick random fallback
function getFallbackEvent() {
    return FALLBACK_EVENTS[Math.floor(Math.random() * FALLBACK_EVENTS.length)];
}

export async function POST(req: Request) {
    if (!genAI) {
        console.warn("No GEMINI_API_KEY found, using fallback.");
        return NextResponse.json(getFallbackEvent());
    }

    try {
        const body = await req.json();
        const { stats, history } = body;

        const prompt = `
        You are a financial literacy game engine for women entrepreneurs.
        
        The player is running a "${stats.businessType}" called "${stats.businessName}".
        Current Stats:
        - Year: ${stats.year} (Age ${stats.year})
        - Cash: $${stats.cash}
        - Business Growth: ${stats.businessGrowth}/100
        - Confidence: ${stats.confidence}/100
        - Reputation: ${stats.reputation}/100

        Recent History: ${JSON.stringify(history)}

        Generate ONE realistic business/financial scenario tailored to a ${stats.businessType}.
        Focus on: Pricing, Cash Flow, Risk, Reinvestment, Negotiation, Scaling.
        Avoid repetition of recent history.
        
        Output JSON ONLY:
        {
            "event": "string (max 2 sentences)",
            "concept": "pricing | cash_flow | negotiation | reinvestment | risk | scaling | debt",
            "choices": [
                {
                    "text": "string (actionable choice)",
                    "effects": {
                        "cash": number (negative for cost, positive for gain),
                        "businessGrowth": number (negative or positive),
                        "confidence": number,
                        "reputation": number
                    }
                }
            ]
        }
        Provide exactly 2 or 3 choices.
        `;

        // Try multiple free-tier models in order of preference. 
        // Note: As of 2026, newer models like 2.5-flash are preferred.
        const modelsToTry = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash", "gemini-pro"];
        let result = null;
        let lastError = null;

        for (const modelName of modelsToTry) {
            try {
                console.log(`Attempting to generate with model: ${modelName}`);
                const model = genAI.getGenerativeModel({ model: modelName });
                result = await model.generateContent(prompt);
                if (result) break; // Success
            } catch (error: any) {
                console.warn(`Model ${modelName} failed:`, error.message || error);
                lastError = error;
                // Continue to next model
            }
        }

        if (!result) {
            console.error("All AI models failed. Last error:", lastError);
            throw lastError || new Error("All models failed");
        }
        const response = await result.response;
        const text = response.text();

        // Cleanup JSON markdown if present
        const jsonStr = text.replace(/```json/g, '').replace(/```/g, '').trim();
        const eventData = JSON.parse(jsonStr);

        return NextResponse.json(eventData);

    } catch (error) {
        console.error("AI Generation failed:", error);
        return NextResponse.json(getFallbackEvent());
    }
}
