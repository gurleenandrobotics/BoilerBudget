"use client";

import React, { useEffect } from 'react';
import { GameProvider, useGame } from '@/components/GameContext';
import { StatsBar } from '@/components/StatsBar';
import { EventCard } from '@/components/EventCard';
import { SummaryScreen } from '@/components/SummaryScreen';
import { BusinessSelection } from '@/components/BusinessSelection';
import { motion } from 'framer-motion';

function GameContent() {
  const { state, currentEvent, nextTurn, isLoading } = useGame();

  // If game is over (e.g. 10 turns? Prompt says 5-10 years)
  // Logic for game over: "Age/year increments", "5-10 years of gameplay"
  // Let's set a limit, say until Age 31 (10 years from 21)
  const isGameOver = state.year >= 31;

  useEffect(() => {
    // Initial load
    // We don't auto-start now, we wait for Business Selection
  }, [state.year, currentEvent, isLoading, state.history.length]);

  if (!state.businessType) {
    return <BusinessSelection />;
  }

  if (isGameOver) {
    return <SummaryScreen />;
  }

  return (
    <div className="h-screen overflow-hidden bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-fixed bg-[#FAFAFA] flex flex-col font-sans text-slate-700 selection:bg-[#F472B6] selection:text-white">
      {/* Subtle pink gradient orb for ambient light */}
      <div className="fixed top-[-20%] left-[-10%] w-[50%] h-[50%] bg-[#F472B6] rounded-full blur-[150px] opacity-[0.1] pointer-events-none" />
      <div className="fixed bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-[#F472B6] rounded-full blur-[150px] opacity-[0.1] pointer-events-none" />

      <StatsBar />

      <main className="flex-1 flex flex-col items-center justify-center p-6 gap-8 z-10 relative">
        {!currentEvent && !isLoading ? (
          <div className="text-center">
            <h1 className="text-5xl font-extralight text-slate-900 mb-6 tracking-tight">
              {`Year ${state.year - 21} Complete`}
            </h1>
            <p className="text-slate-500 mb-10 max-w-md mx-auto leading-relaxed">
              Take a moment to review the growth of <span className="text-[#F472B6] font-medium">{state.businessName}</span>.
            </p>
            <motion.button
              whileHover={{ scale: 1.05, boxShadow: "0 0 20px rgba(244, 114, 182, 0.3)" }}
              whileTap={{ scale: 0.95 }}
              onClick={() => nextTurn()}
              className="px-10 py-4 bg-white border border-[#F472B6] text-[#F472B6] text-lg font-bold rounded-full hover:bg-[#F472B6] hover:text-white transition-all uppercase tracking-widest shadow-sm"
            >
              Start Next Year
            </motion.button>
          </div>
        ) : (
          <div className="w-full flex justify-center">
            <EventCard />
          </div>
        )}
      </main>

      <footer className="p-4 text-center text-slate-400 text-xs">
        Financial Literacy Simulator • Powered by Gemini
      </footer>
    </div>
  );
}

export default function Home() {
  return (
    <GameProvider>
      <GameContent />
    </GameProvider>
  );
}
