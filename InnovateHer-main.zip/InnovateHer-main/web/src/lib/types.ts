export type Stat = 'cash' | 'businessGrowth' | 'confidence' | 'reputation';

export interface GameStats {
  cash: number;
  businessGrowth: number; // 0-100
  confidence: number; // 0-100
  reputation: number; // 0-100
}

export interface GameState extends GameStats {
  year: number; // Starts at 21
  businessType?: string; // e.g., "Tech Startup", "Bakery", "Consulting Firm"
  businessName?: string;
  history: EventLog[];
  isGameOver: boolean;
}

export interface Effect {
  cash?: number;
  businessGrowth?: number;
  confidence?: number;
  reputation?: number;
}

export interface Choice {
  text: string;
  effects: Effect;
}

export interface GameEvent {
  event: string;
  concept: 'pricing' | 'cash_flow' | 'negotiation' | 'reinvestment' | 'risk' | 'scaling' | 'debt' | 'startup';
  choices: Choice[];
}

export interface EventLog {
  year: number;
  event: string;
  choice: string;
  outcome: string; // "Gain/Loss description"
}

export const INITIAL_STATE: GameState = {
  year: 21,
  cash: 5000, // Higher starting capital for age 21
  businessGrowth: 0,
  confidence: 60,
  reputation: 0,
  history: [],
  isGameOver: false,
};
