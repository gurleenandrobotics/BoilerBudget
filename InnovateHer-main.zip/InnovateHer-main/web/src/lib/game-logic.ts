import { GameState, Effect, GameStats } from './types';

export function applyEffect(currentStats: GameStats, effect: Effect): GameStats {
    return {
        cash: Math.max(0, currentStats.cash + (effect.cash || 0)), // Prevent negative cash? Or allow debt? Prompt says "No failure states", so maybe allow negative or cap at 0. let's allow negative for realism but maybe warn. Actually bitlife allows debt.
        businessGrowth: Math.max(0, Math.min(100, currentStats.businessGrowth + (effect.businessGrowth || 0))),
        confidence: Math.max(0, Math.min(100, currentStats.confidence + (effect.confidence || 0))),
        reputation: Math.max(0, Math.min(100, currentStats.reputation + (effect.reputation || 0))),
    };
}

export function formatCurrency(amount: number): string {
    // Use Intl.NumberFormat but mainly for comma separation
    return new Intl.NumberFormat('en-US').format(amount);
}

export function getBusinessStage(growth: number): 'early' | 'growing' | 'established' {
    if (growth < 30) return 'early';
    if (growth < 70) return 'growing';
    return 'established';
}
