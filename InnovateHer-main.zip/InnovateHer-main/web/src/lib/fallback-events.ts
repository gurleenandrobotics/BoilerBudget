import { GameEvent } from './types';

export const FALLBACK_EVENTS: GameEvent[] = [
    {
        event: "A local coffee shop asks if you can design their new menu. They offer to pay you in 'exposure' and free coffee.",
        concept: "negotiation",
        choices: [
            {
                text: "Accept the deal for exposure",
                effects: {
                    cash: 0,
                    businessGrowth: 5,
                    confidence: -5,
                    reputation: 10
                }
            },
            {
                text: "Politely decline and ask for payment",
                effects: {
                    cash: 200,
                    businessGrowth: 0,
                    confidence: 10,
                    reputation: 5
                }
            },
            {
                text: "Negotiate: 50% discount for a portfolio piece",
                effects: {
                    cash: 100,
                    businessGrowth: 10,
                    confidence: 5,
                    reputation: 15
                }
            }
        ]
    },
    {
        event: "You have a sudden influx of orders, but your current equipment is too slow to keep up. You have $1000 in savings.",
        concept: "reinvestment",
        choices: [
            {
                text: "Buy new equipment ($800)",
                effects: {
                    cash: -800,
                    businessGrowth: 20,
                    confidence: 15,
                    reputation: 10
                }
            },
            {
                text: "Work extra hours to meet demand",
                effects: {
                    cash: 0,
                    businessGrowth: 5,
                    confidence: -10,
                    reputation: 5
                }
            },
            {
                text: "Hire a temporary assistant ($300)",
                effects: {
                    cash: -300,
                    businessGrowth: 10,
                    confidence: 5,
                    reputation: 5
                }
            }
        ]
    },
    {
        event: "A competitor lowers their prices significantly. Clients are asking why you are more expensive.",
        concept: "pricing",
        choices: [
            {
                text: "Lower your prices to match",
                effects: {
                    cash: -100, // Reduced margins implications
                    businessGrowth: 5,
                    confidence: -5,
                    reputation: -5
                }
            },
            {
                text: "Keep prices, explain your value",
                effects: {
                    cash: 0,
                    businessGrowth: 0,
                    confidence: 10,
                    reputation: 10
                }
            },
            {
                text: "Raise prices and target premium market",
                effects: {
                    cash: 100, // Ideally higher margins if successful
                    businessGrowth: -5, // Slower growth initially
                    confidence: 15, // Bold move
                    reputation: 20
                }
            }
        ]
    },
    {
        event: "You need a website for your business. A friend offers to build it for cheap, or you can hire a professional agency.",
        concept: "risk",
        choices: [
            {
                text: "DIY with a template (Free)",
                effects: {
                    cash: 0,
                    businessGrowth: 5,
                    confidence: 5,
                    reputation: 0
                }
            },
            {
                text: "Hire the friend ($200)",
                effects: {
                    cash: -200,
                    businessGrowth: 10,
                    confidence: 0,
                    reputation: 5
                }
            },
            {
                text: "Hire the agency ($1500)",
                effects: {
                    cash: -1500,
                    businessGrowth: 25,
                    confidence: 20,
                    reputation: 20
                }
            }
        ]
    },
    {
        event: "A large client wants to place a huge order but demands net-60 payment terms (payment 60 days after delivery).",
        concept: "cash_flow",
        choices: [
            {
                text: "Accept the order",
                effects: {
                    cash: -500, // Upfront costs
                    businessGrowth: 30,
                    confidence: 10,
                    reputation: 15
                }
            },
            {
                text: "Decline, can't float the cost",
                effects: {
                    cash: 0,
                    businessGrowth: 0,
                    confidence: -5,
                    reputation: 0
                }
            },
            {
                text: "Negotiate: 50% upfront",
                effects: {
                    cash: 500, // Upfront payment covers costs
                    businessGrowth: 15,
                    confidence: 10,
                    reputation: 10
                }
            }
        ]
    }
];
