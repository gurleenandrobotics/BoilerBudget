"use client";

import React from 'react';
import { useGame } from '@/components/GameContext';
import { formatCurrency } from '@/lib/game-logic';
import { Coins, TrendingUp, Smile, Users, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';

export function StatsBar() {
    const { state } = useGame();

    const StatItem = ({ icon: Icon, label, value }: { icon: any, label: string, value: string | number }) => (
        <div className="flex flex-col items-center justify-center px-8 py-5 rounded-3xl glass-panel min-w-[160px] border border-[#F472B6]/20 bg-white/60 hover:border-[#F472B6]/50 hover:bg-white/80 transition-all duration-300 group shadow-[0_4px_20px_-5px_rgba(244,114,182,0.15)] hover:shadow-[0_8px_25px_-5px_rgba(244,114,182,0.3)]">
            <div className="text-[#F472B6] mb-3 group-hover:scale-110 transition-transform">
                <Icon size={28} />
            </div>
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-bold group-hover:text-[#F472B6] transition-colors mb-1">{label}</span>
            <strong className="text-slate-800 text-2xl tracking-tighter drop-shadow-sm">{value}</strong>
        </div>
    );

    return (
        <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="flex flex-wrap justify-center gap-16 py-12 px-8 w-full max-w-[90%] mx-auto z-50 relative"
        >
            <StatItem icon={Calendar} label="Year" value={`Age ${state.year}`} />
            <StatItem icon={Coins} label="Capital" value={`${formatCurrency(state.cash)}`} /> {/* Function might need update to remove $ */}
            <StatItem icon={TrendingUp} label="Growth" value={`${state.businessGrowth}%`} />
            <StatItem icon={Smile} label="Confidence" value={`${state.confidence}%`} />
            <StatItem icon={Users} label="Reputation" value={`${state.reputation}%`} />
        </motion.div>
    );
}
