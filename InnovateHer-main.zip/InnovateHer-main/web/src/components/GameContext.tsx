"use client";

import React, { createContext, useContext, useState, ReactNode } from 'react';
import { GameState, GameStats, INITIAL_STATE, GameEvent, Choice } from '@/lib/types';
import { applyEffect } from '@/lib/game-logic';

interface GameContextType {
    state: GameState;
    currentEvent: GameEvent | null;
    isLoading: boolean;
    makeChoice: (choice: Choice) => void;
    nextTurn: () => Promise<void>;
    resetGame: () => void;
    setBusinessDetails: (name: string, type: string) => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export function GameProvider({ children }: { children: ReactNode }) {
    const [state, setState] = useState<GameState>(INITIAL_STATE);
    const [currentEvent, setCurrentEvent] = useState<GameEvent | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const setBusinessDetails = (name: string, type: string) => {
        setState((prev) => ({ ...prev, businessName: name, businessType: type }));
    };

    const makeChoice = (choice: Choice) => {
        setState((prev) => {
            const newStats = applyEffect(prev, choice.effects);
            return {
                ...prev,
                ...newStats,
                history: [
                    ...prev.history,
                    {
                        year: prev.year,
                        event: currentEvent?.event || "Unknown Event",
                        choice: choice.text,
                        outcome: `Cash: ${choice.effects.cash || 0}, Growth: ${choice.effects.businessGrowth || 0}%` // Simplified outcome log
                    }
                ]
            };
        });
        // Optimistically clear event or keep it until next turn?
        // "User selects one choice -> Stats update immediately -> Loop repeats"
        // Usually wait for "Next Year" click?
        // Prompt says: "1. User clicks Next Year ... 7. Loop repeats"
        // So after choice, maybe we wait for next year?
        // "5. User selects one choice, 6. Stats update immediately"
        // Then "User clicks Next Year".
        // So currentEvent should probably reflect "completed" state or just stay visible.
        // Let's clear it or mark as done.
        setCurrentEvent(null);
    };

    const nextTurn = async () => {
        setIsLoading(true);
        // Increment year
        setState((prev) => ({ ...prev, year: prev.year + 1 }));

        try {
            // Prepare payload
            const payload = {
                stats: {
                    cash: state.cash,
                    businessGrowth: state.businessGrowth,
                    confidence: state.confidence,
                    reputation: state.reputation,
                    year: state.year,
                    businessName: state.businessName,
                    businessType: state.businessType
                },
                history: state.history.map(h => h.event).slice(-5) // Send last 5 events context
            };

            const res = await fetch('/api/generate-event', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!res.ok) throw new Error("Failed to fetch event");

            const data = await res.json();
            setCurrentEvent(data);

        } catch (error) {
            console.error("Failed to generate event, using fallback", error);
            // Fallback logic handled in API ideally, but if API fails network-wise:
            const { FALLBACK_EVENTS } = await import('@/lib/fallback-events');
            const randomEvent = FALLBACK_EVENTS[Math.floor(Math.random() * FALLBACK_EVENTS.length)];
            setCurrentEvent(randomEvent);
        } finally {
            setIsLoading(false);
        }
    };

    const resetGame = () => {
        setState(INITIAL_STATE);
        setCurrentEvent(null);
    };

    return (
        <GameContext.Provider value={{ state, currentEvent, isLoading, makeChoice, nextTurn, resetGame, setBusinessDetails }}>
            {children}
        </GameContext.Provider>
    );
}

export function useGame() {
    const context = useContext(GameContext);
    if (context === undefined) {
        throw new Error('useGame must be used within a GameProvider');
    }
    return context;
}
