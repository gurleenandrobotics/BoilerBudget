"use client";

import React from 'react';
import { useGame } from '@/components/GameContext';
import { motion } from 'framer-motion';
import { formatCurrency } from '@/lib/game-logic';

export function SummaryScreen() {
    const { state, resetGame } = useGame();

    const businessOutcome = () => {
        if (state.cash > 100000 && state.businessGrowth > 80) return "Empire Builder";
        if (state.cash > 50000) return "Successful Entrepreneur";
        if (state.cash > 10000) return "Stable Business Owner";
        return "Learning Experience";
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-[#FAFAFA] p-8 text-slate-700">
            <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="glass-card p-10 rounded-3xl max-w-3xl w-full text-center border border-[#F472B6]/20 bg-white/90 shadow-[0_0_60px_-15px_rgba(244,114,182,0.3)]"
            >
                <h1 className="text-4xl font-light text-slate-900 mb-2 tracking-tight">Career Retrospective</h1>
                <p className="text-[#F472B6] font-bold text-xl mb-12 uppercase tracking-widest">{businessOutcome()}</p>

                <div className="grid grid-cols-2 gap-6 mb-12 text-left">
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                        <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Final Capital</p>
                        <p className="text-3xl font-medium text-[#F472B6]">{formatCurrency(state.cash)} Coins</p>
                    </div>
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                        <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Business Growth</p>
                        <p className="text-3xl font-medium text-slate-800">{state.businessGrowth}%</p>
                    </div>
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                        <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Confidence</p>
                        <p className="text-3xl font-medium text-slate-800">{state.confidence}%</p>
                    </div>
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                        <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Reputation</p>
                        <p className="text-3xl font-medium text-slate-800">{state.reputation}%</p>
                    </div>
                </div>

                <div className="mb-12">
                    <h3 className="text-left text-sm font-bold text-slate-500 uppercase tracking-widest mb-4">Key Milestones</h3>
                    <div className="bg-slate-50 rounded-xl p-6 max-h-60 overflow-y-auto text-left space-y-4 border border-slate-100 scrollbar-thin scrollbar-thumb-[#F472B6]/20 shadow-inner">
                        {state.history.map((log, i) => (
                            <div key={i} className="text-sm border-b border-slate-200 last:border-0 pb-4">
                                <span className="font-bold text-[#F472B6]">Age {log.year}:</span> <span className="text-slate-600">{log.event}</span>
                                <div className="text-slate-500 mt-1 pl-4 border-l-2 border-[#F472B6]/30">Selected: <span className="text-slate-400 italic">{log.choice}</span></div>
                            </div>
                        ))}
                    </div>
                </div>

                <button
                    onClick={resetGame}
                    className="px-10 py-4 bg-[#F472B6] text-white rounded-full font-bold hover:bg-pink-400 transition-all uppercase tracking-widest shadow-lg hover:shadow-xl"
                >
                    Start New Career
                </button>
            </motion.div>
        </div>
    );
}
