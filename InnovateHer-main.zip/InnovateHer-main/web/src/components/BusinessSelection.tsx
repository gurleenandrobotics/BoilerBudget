"use client";

import React, { useState } from 'react';
import { useGame } from '@/components/GameContext';
import { motion } from 'framer-motion';

const BUSINESS_TYPES = [
    {
        type: "Tech Startup",
        icon: "💻",
        desc: "High risk, high potential growth. Focus on scaling fast.",
        gradient: "from-blue-500/20 to-cyan-500/10",
        border: "border-blue-500/30",
        iconBg: "bg-blue-500/20",
        iconColor: "text-blue-400"
    },
    {
        type: "Artisan Bakery",
        icon: "🥐",
        desc: "Community focused, steady cash flow. Focus on quality and local reputation.",
        gradient: "from-amber-500/20 to-orange-500/10",
        border: "border-amber-500/30",
        iconBg: "bg-amber-500/20",
        iconColor: "text-amber-400"
    },
    {
        type: "Digital Agency",
        icon: "🎨",
        desc: "Service based, low overhead. Focus on client relationships and pricing.",
        gradient: "from-purple-500/20 to-pink-500/10",
        border: "border-purple-500/30",
        iconBg: "bg-purple-500/20",
        iconColor: "text-purple-400"
    },
    {
        type: "Sustainable Fashion Brand",
        icon: "👗",
        desc: "Product based, inventory costs. Focus on brand and logistics.",
        gradient: "from-emerald-500/20 to-green-500/10",
        border: "border-emerald-500/30",
        iconBg: "bg-emerald-500/20",
        iconColor: "text-emerald-400"
    },
];

export function BusinessSelection() {
    const { setBusinessDetails, nextTurn } = useGame();
    const [name, setName] = useState("");
    const [selectedType, setSelectedType] = useState<string | null>(null);

    const handleStart = () => {
        if (name && selectedType) {
            setBusinessDetails(name, selectedType);
            nextTurn();
        }
    };

    return (
        <div className="min-h-screen bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-fixed bg-[#FAFAFA] text-slate-700 selection:bg-[#F472B6] selection:text-white p-6 flex items-center justify-center relative overflow-hidden">
            {/* Subtle pink gradient orbs for ambient light */}
            <div className="fixed top-[-20%] left-[-10%] w-[50%] h-[50%] bg-[#F472B6] rounded-full blur-[150px] opacity-[0.1] pointer-events-none" />
            <div className="fixed bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-[#F472B6] rounded-full blur-[150px] opacity-[0.1] pointer-events-none" />

            <div className="max-w-6xl w-full mx-auto relative z-10">
                {/* Header Section */}
                <div className="text-center mb-16">
                    <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-slate-900 via-[#F472B6] to-slate-900 bg-clip-text text-transparent">
                        Start Your Legacy
                    </h1>
                    <div className="flex items-center justify-center gap-4 mb-12">
                        <div className="h-px w-20 bg-gradient-to-r from-transparent to-[#F472B6]/50" />
                        <p className="text-[#F472B6] text-lg md:text-xl uppercase tracking-[0.3em] font-medium">
                            Age 21 • Year 1
                        </p>
                        <div className="h-px w-20 bg-gradient-to-l from-transparent to-[#F472B6]/50" />
                    </div>
                </div>

                {/* Business Name Input - Centered and Larger */}
                <div className="flex justify-center mb-20">
                    <div className="w-full max-w-4xl">
                        <h2 className="text-2xl md:text-3xl font-medium text-center mb-8 text-slate-600">
                            What will you name your empire?
                        </h2>
                        <div className="relative w-fit mx-auto">
                            <input
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder="Enter business name..."
                                className="w-[500px] p-8 text-[20px] md:text-6xl text-center bg-white/70 border-2 border-slate-200 text-slate-800 rounded-full focus:border-[#F472B6] focus:outline-none focus:shadow-[0_0_30px_rgba(244,114,182,0.2)] backdrop-blur-sm transition-all duration-300 placeholder-slate-300"
                                autoFocus
                            />
                            <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-[#F472B6]/20 to-transparent blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10" />
                        </div>
                    </div>
                </div>

                {/* Business Types Grid */}
                <div className="mb-20">
                    <h2 className="text-2xl md:text-3xl font-medium text-center mb-12 text-slate-600">
                        Choose your business path
                    </h2>

                    <div className="grid grid-cols-1 gap-6 max-w-2xl mx-[400px] px-4">
                        {BUSINESS_TYPES.map((biz) => (
                            <motion.button
                                key={biz.type}
                                whileHover={{ scale: 1.02 }}
                                onClick={() => setSelectedType(biz.type)}
                                className={`
                                    relative mt-[10px] p-8 rounded-[2.5rem] text-left overflow-hidden group
                                    border-[3px] transition-all duration-300 ease-out
                                    ${selectedType === biz.type
                                        ? 'border-[#F472B6] bg-white shadow-[0_0_40px_rgba(244,114,182,0.25)]'
                                        : 'border-slate-100 bg-white/50 hover:bg-white hover:border-[#F472B6]/30 hover:shadow-lg'
                                    }
                                `}
                            >
                                {/* Selection indicator */}
                                {selectedType === biz.type && (
                                    <>
                                        <div className="absolute top-6 right-6 w-6 h-6 rounded-full bg-[#F472B6] flex items-center justify-center shadow-[0_0_10px_#F472B6]">
                                            <div className="w-2 h-2 rounded-full bg-white" />
                                        </div>
                                    </>
                                )}

                                {/* Content */}
                                <div className="relative z-10">
                                    <div className="flex items-start gap-6">
                                        <div className="shrink-0 p-4 rounded-xl bg-[#F472B6]/20 text-[#F472B6] text-[60px] mr-[50px] border border-[#F472B6]/30 shadow-sm">
                                            {biz.icon}
                                        </div>
                                        <div>
                                            <h3 className={`
                                                text-2xl font-bold mb-2 text-slate-800 tracking-wide
                                            `}>
                                                {biz.type}
                                            </h3>
                                            <p className="text-slate-500 text-base leading-relaxed group-hover:text-slate-700 transition-colors duration-300">
                                                {biz.desc}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </motion.button>
                        ))}
                    </div>
                </div>

                {/* Launch Button */}
                <div className="flex justify-center">
                    <motion.button
                        initial={{ opacity: 0.8 }}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        disabled={!name || !selectedType}
                        onClick={handleStart}
                        className={`
                            relative px-[20px] py-[20px] rounded-full text-xl font-bold uppercase tracking-wider
                            transition-all duration-300 group mt-[25px] shadow-lg
                            ${name && selectedType
                                ? 'bg-gradient-to-r from-[#F472B6] to-pink-400 text-white'
                                : 'bg-slate-200 text-slate-400 border border-slate-300 cursor-not-allowed'
                            }
                        `}
                    >
                        {name && selectedType ? (
                            <>
                                <span className="relative z-10">Launch Business</span>
                                <div className="absolute inset-0 rounded-full bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                            </>
                        ) : (
                            'Launch Business'
                        )}

                        {/* Button glow effect */}
                        {name && selectedType && (
                            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-[#F472B6]/40 to-transparent blur-xl opacity-0 group-hover:opacity-50 transition-opacity duration-300 -z-10" />
                        )}
                    </motion.button>
                </div>
            </div>
        </div>
    );
}