"use client";

import React from 'react';
import { useGame } from '@/components/GameContext';
import { motion, AnimatePresence } from 'framer-motion';


// Let's create a simple Button component inline or use standard HTML button with tailwind for now to avoid dependency on a 'ui' folder I haven't populated yet.
// Prompt said "Choice buttons below the card".

export function EventCard() {
    const { currentEvent, isLoading, makeChoice } = useGame();

    if (isLoading) {
        return (
            <div className="flex flex-col items-center justify-center p-12 h-96 w-full max-w-2xl mx-auto">
                <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-4"></div>
                <p className="text-slate-500 animate-pulse">Generating scenario...</p>
            </div>
        );
    }

    if (!currentEvent) {
        // This state might happen between turns if we clear event. 
        // Or at start before first turn.
        return (
            <div className="flex flex-col items-center justify-center p-12 h-96 text-center">
                <p className="text-slate-400">Ready for the next year?</p>
            </div>
        );
    }

    return (
        <AnimatePresence mode="wait">
            <motion.div
                key={currentEvent.event}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="w-[700px] max-w-3xl bg-white/90 rounded-3xl shadow-[0_0_60px_-15px_rgba(244,114,182,0.4)] border border-[#F472B6]/30 overflow-hidden flex flex-col mx-auto glass-card relative z-20"
            >
                <div className="p-10 pb-6 border-b border-[#F472B6]/10 bg-gradient-to-br from-[#F472B6]/5 to-transparent">
                    <div className="inline-block px-4 py-1.5 bg-[#F472B6]/10 border border-[#F472B6]/20 text-[#F472B6] text-xs font-bold rounded-full mb-6 uppercase tracking-[0.2em]">
                        {currentEvent.concept.replace('_', ' ')}
                    </div>
                    <h2 className="text-4xl md:text-5xl font-light text-slate-800 leading-tight tracking-wide drop-shadow-sm">
                        {currentEvent.event}
                    </h2>
                </div>

                <div className="p-10 pt-12 flex flex-col gap-6 bg-white/50">
                    {currentEvent.choices.map((choice, idx) => (
                        <motion.button
                            key={idx}
                            whileHover={{ y: -4 }}
                            onClick={() => makeChoice(choice)}
                            className="w-full mt-[20px] text-center p-[30px] rounded-[2.5rem] border-[3px] border-[#F472B6]/30 bg-white 
                            hover:bg-pink-50 hover:border-[#F472B6]/50 
                            shadow-[0_10px_30px_-10px_rgba(0,0,0,0.1)] 
                            hover:shadow-[0_20px_40px_-5px_rgba(244,114,182,0.3)] 
                            transition-all duration-300 ease-out group relative overflow-hidden"
                        >
                            <span className="block text-[#F472B6] font-bold group-hover:text-pink-600 transition-colors relative z-2 text-[20px] tracking-wide">
                                {choice.text}
                            </span>
                        </motion.button>
                    ))}
                </div>
            </motion.div>
        </AnimatePresence>
    );
}
